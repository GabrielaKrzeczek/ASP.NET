﻿namespace lab1.Models
{
    public class Kalkulator
    {
        public int A { get; set; }

        public int B { get; set; }

        public string Operacja { get; set; }
    }
}
